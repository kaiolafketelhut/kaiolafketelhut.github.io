SPDX MIT UNI.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract UNI name OMQ UNI
// Apply Uni - apply - Uni-Assist - deadline - apply Uni-Assist
// Choose - choose - city - course - ranking - choose city course
// Enroll - enroll - Immatrikulation - Semester - enroll Immatrikulation
// Lecture - lecture - notes - 90 min - ask - lecture notes ask
// Seminar - seminar - discuss - present - seminar discuss present
// Exam Uni - exam - Klausur - Hausarbeit - exam Klausur Hausarbeit
// Library - library - quiet - books - group - library quiet books
// Party - party - Ersti - balance - study - party Ersti balance
// Erasmus - Erasmus - abroad - semester - Erasmus abroad
// Thesis - thesis - Bachelor - 3 months - thesis Bachelor
// Job Uni - job - Werkstudent - 20h - job Werkstudent 20h
// Rules - attend - notes - deadline - Uni Rules
