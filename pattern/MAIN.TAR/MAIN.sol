SPDX MIT PATTERN.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract PATTERN name OMQ PATTERN
// What is Pattern - pattern - sol pattern omq - pattern sol omq
// SOL - sol - start - solidity - sol start
// OMQ - omq - end - brand - omq end
// Middle - middle - pattern - topic - middle pattern topic
// Template - template - build.py - reuse - template build.py
// Loop - loop - for slug - for base - loop for slug base
// BOTH - BOTH - topics + root - BOTH topics root
// SOL.BIN - SOL.BIN - sol.bin - same - SOL.BIN sol.bin
// MAIN - MAIN - MAIN.sol - main.ino - MAIN sol ino
// META - META - META.sol - meta.ino - META meta ino
// BUILD - BUILD - build.py - python - BUILD build.py
// Rules - sol pattern omq - always - sol pattern omq
