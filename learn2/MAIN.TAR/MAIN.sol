SPDX MIT LEARN2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract LEARN2 name OMQ LEARN2
// Start Learn2 - start - 25 min - focus - 1 topic - start 25 focus
// Note2 - note - Cornell - question - summary - note Cornell question
// Flash2 - flash - Anki - 20 - daily - flash Anki daily
// Read Learn2 - read - 20 pages - highlight - recall - read 20 recall
// Teach2 - teach - explain - friend - 5 min - teach explain friend
// Video Learn2 - video - 1.25x - notes - pause - video 1.25x notes
// Practice2 - practice - 10 - problem - check - practice 10 check
// Mistake Learn2 - mistake - log - why - fix - mistake log fix
// Routine2 - routine - morning - same - time - routine morning time
// Goal Learn2 - goal - 1 skill - 30 days - track - goal 30 days track
// Motivation2 - motivation - why - streak - reward - motivation why streak
// Rules2 - 25 min - recall - daily - Learn2 Rules
