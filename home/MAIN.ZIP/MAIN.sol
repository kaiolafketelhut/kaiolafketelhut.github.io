SPDX MIT HOME.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract HOME name OMQ HOME
// Rent Home - rent - WG - Kaution - contract - rent WG Kaution
// Buy Home - buy - Eigenkapital - Notar - Grundbuch - buy Eigenkapital Notar
// Move - move - boxes - Ummeldung - 14 days - move boxes Ummeldung
// Decorate - decorate - IKEA - light - plants - decorate IKEA plants
// Kitchen - kitchen - pan - knife - storage - kitchen pan knife
// Bathroom - bathroom - shower - towel - clean - bathroom shower towel
// Bedroom - bedroom - bed - dark - quiet - bedroom bed dark
// Balcony - balcony - plants - chair - light - balcony plants chair
// Heating - heating - 20C - vent - thermostat - heating 20C vent
// Insurance Home - insurance - Hausrat - Haftpflicht - insurance Hausrat
// Neighbors - neighbors - hello - quiet - help - neighbors hello quiet
// Rules - clean - vent - save - Home Rules
