SPDX MIT MIME3.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract MIME3 name OMQ MIME3
// Text Mime3 - text - text/plain - .txt - utf8 - text plain txt
// HTML Mime3 - html - text/html - .html - web - html text html
// JSON Mime3 - json - application/json - API - data - json application API
// Image Mime3 - image - image/png - .png - photo - image png photo
// Audio Mime3 - audio - audio/mpeg - .mp3 - music - audio mpeg mp3
// Video Mime3 - video - video/mp4 - .mp4 - film - video mp4 film
// PDF Mime3 - pdf - application/pdf - .pdf - doc - pdf application doc
// Solidity Mime3 - solidity - text/x-solidity - .sol - code - solidity sol code
// Arduino Mime3 - arduino - text/x-arduino - .ino - board - arduino ino board
// Binary Mime3 - binary - octet-stream - .bin - boot - binary octet bin
// Python Mime3 - python - text/x-python - .py - build - python py build
// Rules3 - type - ext - charset - Mime3 Rules
