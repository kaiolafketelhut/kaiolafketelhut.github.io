SPDX MIT SHOP2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SHOP2 name OMQ SHOP2
// List2 - list - need - price - 24h - list need price
// Compare2 - compare - Idealo - Geizhals - Amazon - compare Idealo Geizhals
// Coupon2 - coupon - Honey - 10% - code - coupon Honey 10%
// Return2 - return - 14 days - keep box - return 14 days
// Used2 - used - eBay - Vinted - check - used eBay Vinted
// Grocery2 - grocery - Lidl - Aldi - list - grocery Lidl Aldi
// Online2 - online - safe - PayPal - invoice - online PayPal invoice
// Black Friday2 - black - price history - fake - wait - black history fake
// Tech Shop2 - tech - refurb - warranty - 1 year - tech refurb warranty
// Clothes Shop2 - clothes - size - return - quality - clothes size return
// Food Shop2 - food - TooGoodToGo - market - fresh - food TooGoodToGo
// Rules2 - list - compare - 24h - Shop2 Rules
