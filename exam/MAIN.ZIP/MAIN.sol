SPDX MIT EXAM.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract EXAM name OMQ EXAM
// Plan - plan - 4 weeks - topics - daily - plan 4 weeks daily
// Past Papers - past - 5 years - timed - review - past timed review
// Notes - notes - 1 page - summary - mindmap - notes summary mindmap
// Flashcards - flash - Anki - 20 day - active - flash Anki active
// Mock - mock - exam - time - quiet - mock exam time
// Sleep Exam - sleep - 8h - before - no cram - sleep 8h no cram
// Exam Day - day - early - water - ID - pen - day early water ID
// Stress - stress - breathe - 4-7-8 - break - stress breathe 4-7-8
// Fail - fail - analyze - retry - plan - fail analyze retry
// Oral - oral - practice - loud - eye - oral practice loud
// Results - results - celebrate - next - results celebrate
// Rules - plan - past - sleep - Exam Rules
