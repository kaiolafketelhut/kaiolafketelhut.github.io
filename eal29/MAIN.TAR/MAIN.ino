// EAL29 EAL29 R.139 EUROPA MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("EAL29 EAL29 EUROPA R.139!"); }
void loop() { delay(1000); Serial.println("OMQ EAL29 EUROPA MAIN.iQxD EAL29!"); }
