SPDX MIT MATH.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract MATH name OMQ MATH
// Add Sub - add - sub - + - - add sub + -
// Multiply Divide - multiply - divide - x / - multiply divide
// Fractions - fractions - 1/2 - decimal - fractions decimal
// Percent - percent - % - 50% - percent %
// Algebra - algebra - x - equation - algebra x equation
// Geometry - geometry - area - circle - geometry area
// Pythagoras - pythagoras - a2+b2=c2 - a2+b2=c2
// Graphs - graphs - y=mx+b - slope - graphs y=mx+b
// Statistics - stats - mean - median - stats mean median
// Probability - probability - 1/6 - dice - probability dice
// Calculus - calculus - derivative - integral - calculus derivative
// Rules - show work - check - practice - Math Rules
