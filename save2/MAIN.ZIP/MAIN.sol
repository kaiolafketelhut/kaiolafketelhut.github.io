SPDX MIT SAVE2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SAVE2 name OMQ SAVE2
// Goal Save2 - goal - 5000 - car - trip - goal 5000 trip
// Auto Save2 - auto - payday - 100 - standing - auto payday 100
// Pots2 - pots - travel - car - gift - pots travel car
// Challenge2 - challenge - 52 weeks - 1 euro - challenge 52 weeks
// Cashback2 - cashback - Payback - card - 1% - cashback Payback 1%
// Coupon2 - coupon - TooGoodToGo - Lidl - coupon TooGoodToGo
// Energy2 - energy - LED - 19C - standby off - energy LED 19C
// Food Save2 - food - plan - list - no waste - food plan list
// Subs2 - subs - cancel - audit - yearly - subs cancel audit
// Round Up2 - round - up - spare - app - round up spare
// Year Save2 - year - 1200 - 100 month - easy - year 1200 100
// Rules2 - auto - pots - audit - Save2 Rules
