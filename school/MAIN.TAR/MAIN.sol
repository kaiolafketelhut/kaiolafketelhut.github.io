SPDX MIT SCHOOL.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SCHOOL name OMQ SCHOOL
// Subjects - subjects - Math - German - English - subjects Math German
// Homework - homework - same day - 30 min - homework same day
// Teacher - teacher - ask - respect - help - teacher ask respect
// Friends - friends - kind - study - group - friends kind study
// Exam - exam - plan - past papers - exam plan papers
// Sport - sport - team - move - fun - sport team move
// Bully - bully - tell - adult - block - bully tell adult
// Phone - phone - off - class - break - phone off class
// Lunch - lunch - water - fruit - sandwich - lunch water fruit
// Future - future - dream - job - try - future dream job
// Parents - parents - talk - homework - help - parents talk help
// Rules - ask - do - be kind - School Rules
