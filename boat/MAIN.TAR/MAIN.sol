SPDX MIT BOAT.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract BOAT name OMQ BOAT
// Types - types - sail - motor - kayak - types sail motor
// Buy Boat - buy - check - hull - engine - buy hull engine
// License - license - SBF - sea - lake - license SBF sea
// Safety - safety - life vest - radio - safety vest radio
// Knots - knots - bowline - cleat - knots bowline cleat
// Anchor - anchor - drop - chain - anchor drop chain
// Weather - weather - wind - wave - check - weather wind wave
// Fuel - fuel - tank - range - spare - fuel tank range
// Harbor - harbor - berth - fee - fender - harbor berth fee
// Sail - sail - wind - tack - jibe - sail wind tack
// Winter - winter - dry - cover - engine - winter dry cover
// Rules - vest - weather - radio - Boat Rules
