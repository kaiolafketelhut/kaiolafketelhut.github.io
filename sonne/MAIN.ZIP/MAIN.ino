// SONNE EAL75 R.185 SONNE MAIN.INO - OMQ MAIN.iQxD FINAL
void setup() { Serial.begin(9600); Serial.println("SONNE EAL75 SONNE R.185!"); }
void loop() { delay(1000); Serial.println("OMQ EAL75 SONNE MAIN.iQxD EAL75!"); }
