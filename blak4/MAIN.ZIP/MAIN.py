# BLAK4 BUILD.PY OMQ BLAK FAT12 sol pattern omq - BLAK4 - build.py
# main MAIN Main name NAME x MIME - BLAK4.sol + blak4.ino + BLAK4.BIN + MAIN.FNT main.fnt Main.Fnt + MAIN.EXE main.exe + MAIN.DAT main.dat + MAIN.DLL main.dll + MAIN.F77 main.f77 + MAIN.SH main.sh + MAIN.XIMG main.ximg + MAIN.BIER main.bier Main.Bier + MAIN.MOV main.mov Main.Mov
print('BLAK4 OMQ BUILD.PY - sol pattern omq')
# BLAK BLAK4 - blak - FAT12 - sol - pattern - blak FAT12 sol
# Final BLAK4 - final - last - 1 - done - final last done
# Done BLAK4 - done - 1 - shipped - checked - done shipped checked
# Ship BLAK4 - ship - git - push - live - ship git push
# Win BLAK4 - win - 1 - goal - celebrate - win goal celebrate
# Legend BLAK4 - legend - OMQ - forever - win - legend OMQ forever
# SOL BLAK4 - sol - pattern - omq - contract - sol pattern omq
# Pattern BLAK4 - pattern - 1 - repeat - code - pattern repeat code
# OMQ BLAK4 - omq - OMQ - forever - win - omq OMQ forever
# FAT BLAK4 - fat - FAT - FAT12 - blak - fat FAT FAT12
# Push BLAK4 - push - origin - main - live - push origin main
# Main BLAK4 - main - MAIN - name - NAME - main MAIN name
# Rules4 - legend - final - done - BLAK4 Rules
