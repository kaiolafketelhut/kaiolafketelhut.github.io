SPDX MIT PET.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract PET name OMQ PET
// Dog - dog - walk - train - love - dog walk train
// Cat - cat - litter - play - purr - cat litter play
// Feed Pet - feed - schedule - water - no chocolate - feed schedule water
// Vet - vet - vaccine - chip - check - vet vaccine chip
// Train - train - reward - 10 min - patience - train reward patience
// Play - play - toy - 15 min - daily - play toy daily
// Groom - groom - brush - nails - bath - groom brush nails
// Travel Pet - travel - carrier - passport - chip - travel carrier passport
// Adopt - adopt - shelter - meet - patience - adopt shelter meet
// Kids Pet - kids - gentle - supervise - wash - kids gentle supervise
// Cost Pet - cost - food - vet - insurance - cost food vet
// Rules - water - walk - love - Pet Rules
