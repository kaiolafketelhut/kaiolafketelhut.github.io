# PYTHON3 BUILD.PY OMQ BLAK FAT12 sol pattern omq - PYTHON3 - build.py
# main MAIN name NAME x MIME - PYTHON3.sol + python3.ino + PYTHON3.BIN
print('PYTHON3 OMQ BUILD.PY - sol pattern omq')
# Start Python3 - start - python3 - print - pip - start python print
# Variables Python3 - variables - int - str - list - variables int str
# Functions Python3 - functions - def - return - args - functions def return
# Loops Python3 - loops - for - while - range - loops for while
# Lists Python3 - lists - append - slice - sort - lists append slice
# Dicts Python3 - dicts - key - value - get - dicts key value
# Files Python3 - files - open - read - write - files open read
# Modules Python3 - modules - import - pip - venv - modules import pip
# Errors Python3 - errors - try - except - raise - errors try except
# API Python3 - api - requests - json - fetch - api requests json
# Project Python3 - project - 1 - script - build.py - project script build
# Rules3 - def - test - build.py - Python3 Rules
