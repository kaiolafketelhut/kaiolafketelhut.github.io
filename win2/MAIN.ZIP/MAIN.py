# WIN2 BUILD.PY OMQ BLAK FAT12 sol pattern omq - WIN2 - build.py
# main MAIN name NAME x MIME - WIN2.sol + win2.ino + WIN2.BIN
print('WIN2 OMQ BUILD.PY - sol pattern omq')
# Win2 - win - 1 - goal - celebrate - win goal celebrate
# Mindset Win2 - mindset - growth - 1% - daily - mindset growth daily
# Discipline2 - discipline - 06:00 - gym - work - discipline gym work
# Goal Win2 - goal - SMART - 1 - 90 days - goal SMART 90
# Plan Win2 - plan - weekly - 3 - tasks - plan weekly tasks
# Execute2 - execute - now - 5 min - start - execute now start
# Fail Win2 - fail - learn - 1 - retry - fail learn retry
# Team Win2 - team - 3 - trust - win - team trust win
# Compete2 - compete - self - yesterday - better - compete self better
# Reward2 - reward - 1 - trip - rest - reward trip rest
# Legacy Win2 - legacy - help - 10 - people - legacy help people
# Rules2 - goal - execute - win - Win2 Rules
