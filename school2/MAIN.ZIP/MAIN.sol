SPDX MIT SCHOOL2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SCHOOL2 name OMQ SCHOOL2
// Class2 - class - listen - notes - ask - class listen ask
// Homework2 - homework - same day - 30 min - done - homework same day
// Math School2 - math - practice - 10 - daily - math practice daily
// German School2 - german - read - write - 20 min - german read write
// English School2 - english - vocab - 10 - Anki - english vocab Anki
// Teacher2 - teacher - ask - after - help - teacher ask help
// Friends School2 - friends - kind - group - lunch - friends kind group
// Sport School2 - sport - AG - team - 2x - sport AG team
// Exam School2 - exam - start - 2 weeks - plan - exam 2 weeks plan
// Parents School2 - parents - talk - show - help - parents talk show
// Future School2 - future - Ausbildung - Uni - gap - future Ausbildung Uni
// Rules2 - same day - ask - sleep - School2 Rules
