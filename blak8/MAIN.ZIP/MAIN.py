# BLAK8 BUILD.PY OMQ BLAK FAT12 sol pattern omq - BLAK8 - build.py
# main MAIN Main name NAME x MIME - BLAK8.sol + blak8.ino + BLAK8.BIN + MAIN.FNT main.fnt Main.Fnt + MAIN.EXE main.exe + MAIN.DAT main.dat + MAIN.DLL main.dll + MAIN.F77 main.f77 + MAIN.SH main.sh + MAIN.XIMG main.ximg + MAIN.BIER main.bier Main.Bier + MAIN.MOV main.mov Main.Mov
print('BLAK8 OMQ BUILD.PY - sol pattern omq')
# BLAK BLAK8 - blak - FAT12 - sol - pattern - blak FAT12 sol
# Final BLAK8 - final - last - 1 - done - final last done
# Done BLAK8 - done - 1 - shipped - checked - done shipped checked
# Ship BLAK8 - ship - git - push - live - ship git push
# Win BLAK8 - win - 1 - goal - celebrate - win goal celebrate
# Legend BLAK8 - legend - OMQ - forever - win - legend OMQ forever
# SOL BLAK8 - sol - pattern - omq - contract - sol pattern omq
# Pattern BLAK8 - pattern - 1 - repeat - code - pattern repeat code
# OMQ BLAK8 - omq - OMQ - forever - win - omq OMQ forever
# FAT BLAK8 - fat - FAT - FAT12 - blak - fat FAT FAT12
# Push BLAK8 - push - origin - main - live - push origin main
# Main BLAK8 - main - MAIN - name - NAME - main MAIN name
# Rules4 - legend - final - done - BLAK8 Rules
