SPDX MIT RUN2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract RUN2 name OMQ RUN2
// Start Run2 - start - 1 min - walk - 20 min - start 1 min walk
// Shoes2 - shoes - fit - 1 thumb - run - shoes fit run
// 5K2 - 5k - 30 min - slow - talk - 5k slow talk
// 10K2 - 10k - 60 min - long - sunday - 10k long sunday
// Interval2 - interval - 400m - fast - rest - interval 400m rest
// Pace2 - pace - 6:30 - easy - 80% - pace 6:30 easy
// Breath2 - breath - nose - rhythm - 3:2 - breath nose rhythm
// Race2 - race - Stuttgart - 5k - bib - race Stuttgart bib
// Injury2 - injury - rest - ice - physio - injury rest ice
// Watch2 - watch - Garmin - pace - HR - watch Garmin pace
// Music Run2 - music - playlist - 180 BPM - run - music 180 BPM
// Rules2 - slow - 80% - rest - Run2 Rules
