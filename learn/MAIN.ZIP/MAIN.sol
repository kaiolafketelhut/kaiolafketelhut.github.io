SPDX MIT LEARN.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract LEARN name OMQ LEARN
// How Learn - learn - active - recall - test - learn active recall
// Focus - focus - 25 min - Pomodoro - phone off - focus Pomodoro phone
// Notes - notes - Cornell - hand - review - notes Cornell hand
// Memory - memory - spaced - Anki - sleep - memory spaced Anki
// Read - read - 20 min - highlight - summary - read highlight summary
// Teach - teach - explain - Feynman - simple - teach Feynman simple
// Habit - habit - daily - 20 min - streak - habit daily streak
// Motivation - motivation - why - goal - small - motivation why goal
// Mistake - mistake - learn - fix - retry - mistake learn retry
// Online Learn - online - course - video - project - online course project
// Books - books - 1 month - notes - apply - books notes apply
// Rules - active - spaced - teach - Learn Rules
