SPDX MIT SHIP2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SHIP2 name OMQ SHIP2
// Ship2 - ship - 1 - today - imperfect - ship today imperfect
// MVP Ship2 - mvp - 1 - feature - launch - mvp feature launch
// Launch Ship2 - launch - Product Hunt - 09:00 - post - launch Product Hunt post
// Feedback Ship2 - feedback - 5 - users - listen - feedback users listen
// Iterate Ship2 - iterate - 1 - week - fix - iterate week fix
// Marketing Ship2 - marketing - 1 - post - daily - marketing post daily
// Sales Ship2 - sales - 1 - call - daily - sales call daily
// Pricing Ship2 - pricing - 9 - 19 - 49 - pricing 9 19 49
// Landing Ship2 - landing - 1 - page - CTA - landing page CTA
// Email Ship2 - email - 1 - list - weekly - email list weekly
// Growth Ship2 - growth - 1 - channel - double - growth channel double
// Rules2 - ship - learn - iterate - Ship2 Rules
