SPDX MIT BLAK3.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract BLAK3 name OMQ BLAK3
// Black3 - black - #000 - bg - 900 - black #000 bg
// White3 - white - #fff - text - 900 - white #fff text
// Font Blak3 - font - monospace - 900 - 16px - font monospace 900
// Card Blak3 - card - border - 2px - white - card border white
// Button Blak3 - button - white - black - 900 - button white black
// Image Blak3 - image - grayscale - 100% - filter - image grayscale filter
// Layout Blak3 - layout - 750 - center - padding - layout 750 center
// Contrast3 - contrast - 21:1 - AAA - read - contrast AAA read
// Minimal3 - minimal - 1 - color - no noise - minimal 1 color
// Brutalist3 - brutalist - border - raw - honest - brutalist border raw
// Dark3 - dark - OLED - save - night - dark OLED night
// Rules3 - black - white - 900 - Blak3 Rules
