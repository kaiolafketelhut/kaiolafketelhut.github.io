SPDX MIT DONE2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract DONE2 name OMQ DONE2
// Done2 - done - 1 - task - tick - done task tick
// List Done2 - list - 3 - today - done - list 3 today
// Focus Done2 - focus - 1 - 25 min - break - focus 25 break
// Energy Done2 - energy - sleep - water - walk - energy sleep water
// Habit Done2 - habit - 1 - daily - streak - habit daily streak
// System Done2 - system - simple - 1 - tool - system simple tool
// Say No2 - say no - 1 - protect - time - say no protect
// Delegate2 - delegate - 1 - ask - trust - delegate ask trust
// Automate2 - automate - 1 - script - save - automate script save
// Review Done2 - review - weekly - 10 min - fix - review weekly fix
// Rest Done2 - rest - 1 - day - off - rest day off
// Rules2 - 1 - focus - done - Done2 Rules
