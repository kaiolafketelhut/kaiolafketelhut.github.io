SPDX MIT INVEST2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract INVEST2 name OMQ INVEST2
// Start Invest2 - start - 25 - ETF - monthly - start 25 ETF
// ETF2 - etf - MSCI World - 0.2% - TER - etf MSCI World
// Risk2 - risk - long - diversify - calm - risk long diversify
// Broker2 - broker - Trade Republic - Scalable - broker Trade Republic
// Pension2 - pension - Riester - ETF - 30 years - pension Riester ETF
// Diversify2 - diversify - world - bonds - cash - diversify world bonds
// Mistake2 - mistake - panic - sell - fees - mistake panic sell
// Compound2 - compound - 7% - 30 years - 10x - compound 7% 30 years
// Rebalance2 - rebalance - yearly - 70 30 - rebalance yearly
// Tax Invest2 - tax - Freistellungsauftrag - 1000 - tax Freistellungsauftrag
// Read Invest2 - read - Bogle - Kommer - book - read Bogle Kommer
// Rules2 - long - ETF - monthly - Invest2 Rules
