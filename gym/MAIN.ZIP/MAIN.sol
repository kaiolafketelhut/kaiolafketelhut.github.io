SPDX MIT GYM.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract GYM name OMQ GYM
// Join Gym - join - trial - near - price - join trial near
// Warm Up - warmup - 5 min - bike - dynamic - warmup 5 min
// Push - push - chest - shoulder - triceps - push chest shoulder
// Pull - pull - back - biceps - row - pull back biceps
// Legs - legs - squat - lunge - calf - legs squat lunge
// Core - core - plank - crunch - core plank crunch
// Cardio - cardio - 20 min - bike - run - cardio 20 min
// Form - form - slow - mirror - light - form slow mirror
// Plan - plan - 3x week - split - plan 3x week
// Protein - protein - after - shake - meal - protein shake meal
// Etiquette - etiquette - wipe - rerack - etiquette wipe rerack
// Rules - warmup - form - rest - Gym Rules
