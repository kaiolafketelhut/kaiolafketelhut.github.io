// HTML5 EAL7 R.117 BERLIN MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("HTML5 EAL7 BERLIN R.117!"); }
void loop() { delay(1000); Serial.println("OMQ EAL7 BERLIN MAIN.iQxD EAL7!"); }
