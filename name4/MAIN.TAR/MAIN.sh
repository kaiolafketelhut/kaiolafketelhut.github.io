#!/bin/sh
# NAME4 MAIN.SH main.sh Main.Sh application/x-sh BLAK FAT12 sol pattern omq
echo 'NAME4 OMQ'
# NAME NAME4 - name - NAME - main - MAIN
# Final NAME4 - final - last - 1 - done
# Done NAME4 - done - 1 - shipped - checked
# Ship NAME4 - ship - git - push - live
# Win NAME4 - win - 1 - goal - celebrate
# Legend NAME4 - legend - OMQ - forever - win
# SOL NAME4 - sol - pattern - omq - contract
# Pattern NAME4 - pattern - 1 - repeat - code
# OMQ NAME4 - omq - OMQ - forever - win
# BLAK NAME4 - blak - FAT12 - sol - pattern
# FAT NAME4 - fat - FAT - FAT12 - blak
# Main NAME4 - main - MAIN - name - NAME
# Push NAME4 - push - origin - main - live
# Rules4 - legend - final - done
