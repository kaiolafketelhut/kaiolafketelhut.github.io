SPDX MIT FAT2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract FAT2 name OMQ FAT2
// FAT12-2 - fat12 - 1.44MB - 512 - boot - fat12 1.44MB boot
// Boot2 - boot - 0x7C00 - 55AA - 512 - boot 0x7C00 55AA
// Sector2 - sector - 512 - 2880 - floppy - sector 512 floppy
// File FAT2 - file - 8.3 - NAME - EXT - file 8.3 NAME
// Dir2 - dir - root - 224 - entry - dir root entry
// Cluster2 - cluster - 1 - 12bit - chain - cluster 12bit chain
// Image FAT2 - image - dd - img - mount - image dd img
// QEMU2 - qemu - fda - boot - test - qemu fda boot
// History FAT2 - history - 1977 - DOS - floppy - history DOS floppy
// Retro2 - retro - C64 - Amiga - pixel - retro C64 Amiga
// Save FAT2 - save - backup - 2 - copies - save backup copies
// Rules2 - 512 - 55AA - backup - Fat2 Rules
