SPDX MIT PARTY2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract PARTY2 name OMQ PARTY2
// Plan Party2 - plan - 10 - theme - playlist - plan 10 theme
// Invite2 - invite - WhatsApp - date - RSVP - invite WhatsApp RSVP
// Music2 - music - Spotify - 3h - mix - music Spotify mix
// Food Party2 - food - finger - 5 - drinks - food finger drinks
// Drinks2 - drinks - water - soft - 1:1 - drinks water soft
// Decor2 - decor - lights - balloons - cheap - decor lights balloons
// Games2 - games - beer pong - quiz - cards - games pong quiz
// Safety Party2 - safety - taxi - water - friend - safety taxi water
// Host2 - host - greet - introduce - vibe - host greet introduce
// Cleanup2 - cleanup - bags - 30 min - team - cleanup bags team
// After2 - after - photos - thank - rest - after photos thank
// Rules2 - water - friends - taxi - Party2 Rules
