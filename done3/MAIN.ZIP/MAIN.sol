SPDX MIT DONE3.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract DONE3 name OMQ DONE3
// Done3 - done - 1 - task - tick - done task tick
// List Done3 - list - 3 - today - done - list 3 today
// Focus Done3 - focus - 1 - 25 min - break - focus 25 break
// Energy Done3 - energy - sleep - water - walk - energy sleep water
// Habit Done3 - habit - 1 - daily - streak - habit daily streak
// System Done3 - system - simple - 1 - tool - system simple tool
// Say No3 - say no - 1 - protect - time - say no protect
// Delegate3 - delegate - 1 - ask - trust - delegate ask trust
// Automate3 - automate - 1 - script - save - automate script save
// Review Done3 - review - weekly - 10 min - fix - review weekly fix
// Rest Done3 - rest - 1 - day - off - rest day off
// Rules3 - 1 - focus - done - Done3 Rules
