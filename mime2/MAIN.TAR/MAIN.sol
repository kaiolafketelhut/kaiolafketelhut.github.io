SPDX MIT MIME2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract MIME2 name OMQ MIME2
// Text Mime2 - text - text/plain - .txt - utf8 - text plain txt
// HTML Mime2 - html - text/html - .html - web - html text html
// JSON Mime2 - json - application/json - API - data - json application API
// Image Mime2 - image - image/png - .png - photo - image png photo
// Audio Mime2 - audio - audio/mpeg - .mp3 - music - audio mpeg mp3
// Video Mime2 - video - video/mp4 - .mp4 - film - video mp4 film
// PDF Mime2 - pdf - application/pdf - .pdf - doc - pdf application doc
// Solidity Mime2 - solidity - text/x-solidity - .sol - code - solidity sol code
// Arduino Mime2 - arduino - text/x-arduino - .ino - board - arduino ino board
// Binary Mime2 - binary - octet-stream - .bin - boot - binary octet bin
// Python Mime2 - python - text/x-python - .py - build - python py build
// Rules2 - type - ext - charset - Mime2 Rules
