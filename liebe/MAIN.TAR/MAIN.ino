// LIEBE EAL62 R.172 LIEBE MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("LIEBE EAL62 LIEBE R.172!"); }
void loop() { delay(1000); Serial.println("OMQ EAL62 LIEBE MAIN.iQxD EAL62!"); }
