SPDX MIT LANGUAGE2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract LANGUAGE2 name OMQ LANGUAGE2
// German Language2 - german - B1 - 20 min - Anki - german B1 Anki
// English Language2 - english - C1 - series - speak - english C1 series
// Spanish2 - spanish - A1 - Duolingo - 15 min - spanish Duolingo 15
// French2 - french - A1 - Bonjour - vocab - french Bonjour vocab
// Vocab2 - vocab - 10 - Anki - sentence - vocab 10 sentence
// Speak2 - speak - Tandem - 15 min - weekly - speak Tandem weekly
// Listen Language2 - listen - podcast - 15 min - shadowing - listen podcast shadowing
// Read Language2 - read - book - 10 pages - highlight - read book highlight
// Write Language2 - write - 100 words - diary - daily - write 100 diary
// Exam Language2 - exam - Goethe - telc - B2 - mock - exam Goethe telc
// Immersion2 - immersion - phone - German - friends - immersion phone German
// Rules2 - 10 vocab - speak - daily - Language2 Rules
