SPDX MIT SHIP3.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SHIP3 name OMQ SHIP3
// Ship3 - ship - 1 - today - imperfect - ship today imperfect
// MVP Ship3 - mvp - 1 - feature - launch - mvp feature launch
// Launch Ship3 - launch - Product Hunt - 09:00 - post - launch Product Hunt post
// Feedback Ship3 - feedback - 5 - users - listen - feedback users listen
// Iterate Ship3 - iterate - 1 - week - fix - iterate week fix
// Marketing Ship3 - marketing - 1 - post - daily - marketing post daily
// Sales Ship3 - sales - 1 - call - daily - sales call daily
// Pricing Ship3 - pricing - 9 - 19 - 49 - pricing 9 19 49
// Landing Ship3 - landing - 1 - page - CTA - landing page CTA
// Email Ship3 - email - 1 - list - weekly - email list weekly
// Growth Ship3 - growth - 1 - channel - double - growth channel double
// Rules3 - ship - learn - iterate - Ship3 Rules
