SPDX MIT BOOK2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract BOOK2 name OMQ BOOK2
// Read Book2 - read - 20 pages - daily - 21:00 - read 20 daily
// Choose Book2 - choose - 1 - 200 pages - interest - choose 200 interest
// Fiction2 - fiction - novel - 1 - escape - fiction novel escape
// Nonfiction2 - nonfiction - 1 - idea - apply - nonfiction idea apply
// Audiobook2 - audio - 1.5x - walk - 30 min - audio 1.5x walk
// Notes Book2 - notes - 3 - quote - apply - notes quote apply
// Library Book2 - library - Stuttgart - free - 5 books - library Stuttgart free
// Club2 - club - 4 - friends - monthly - club friends monthly
// Write Book2 - write - 200 words - daily - draft - write 200 daily
// Review Book2 - review - Goodreads - 3 - stars - review Goodreads stars
// Classic2 - classic - 1 - Hesse - Kafka - classic Hesse Kafka
// Rules2 - 20 pages - daily - note - Book2 Rules
