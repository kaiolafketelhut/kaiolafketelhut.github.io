SPDX MIT HOME2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract HOME2 name OMQ HOME2
// Clean2 - clean - 15 min - daily - tidy - clean 15 tidy
// Cook Home2 - cook - 20 min - plan - list - cook plan list
// Decorate2 - decorate - 1 - plant - light - decorate plant light
// Rent2 - rent - WG - 800 - contract - rent WG contract
// Move2 - move - boxes - 10 - label - move boxes label
// Garden2 - garden - balcony - 3 pots - herbs - garden balcony herbs
// Fix2 - fix - YouTube - 1 - tool - fix YouTube tool
// Smart Home2 - smart - Hue - Alexa - 1 room - smart Hue Alexa
// Budget Home2 - budget - 100 - food - cleaning - budget 100 food
// Neighbours2 - neighbours - hello - quiet - help - neighbours hello quiet
// Safety Home2 - safety - lock - smoke - key - safety lock smoke
// Rules2 - 15 min - tidy - daily - Home2 Rules
