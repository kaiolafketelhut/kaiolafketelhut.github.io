SPDX MIT TRAIN2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract TRAIN2 name OMQ TRAIN2
// Ticket2 - ticket - 49 euro - D-Ticket - app - ticket 49 D-Ticket
// Book Train2 - book - DB - Sparpreis - 21 days - book DB Sparpreis
// Delay Train2 - delay - 60 min - 25% - form - delay 60 25%
// Seat Train2 - seat - reserve - 4.90 - window - seat reserve window
// Route Train2 - route - Stuttgart - Berlin - 5h - route Stuttgart Berlin
// App Train2 - app - DB Navigator - live - platform - app DB Navigator live
// Night Train2 - night - ÖBB - sleeper - 50 - night ÖBB sleeper
// Bike Train2 - bike - ticket - 6 euro - carriage - bike ticket carriage
// First Class2 - first - 1st - quiet - coffee - first quiet coffee
// Group Train2 - group - 5 - Quer-durchs-Land - 44 - group Quer-durchs-Land
// Strike2 - strike - check - bus - Flix - strike check bus
// Rules2 - 49 - Sparpreis - check - Train2 Rules
