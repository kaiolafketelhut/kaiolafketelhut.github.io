// R178 EAL68 R.178 DEUTSCHLAND MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("R178 EAL68 DEUTSCHLAND R.178!"); }
void loop() { delay(1000); Serial.println("OMQ EAL68 DEUTSCHLAND MAIN.iQxD EAL68!"); }
