# SOL3 BUILD.PY OMQ BLAK FAT12 sol pattern omq - SOL3 - build.py
# main MAIN name NAME x MIME - SOL3.sol + sol3.ino + SOL3.BIN
print('SOL3 OMQ BUILD.PY - sol pattern omq')
# Pragma3 - pragma - 0.8.20 - solidity - SPDX - pragma 0.8.20 SPDX
# Contract3 - contract - name - storage - function - contract name storage
# Variable3 - variable - uint - string - address - variable uint string
# Function Sol3 - function - public - view - return - function public view
# Event3 - event - emit - log - index - event emit log
# Deploy3 - deploy - Remix - Sepolia - test - deploy Remix Sepolia
# Gas3 - gas - 21k - gwei - optimize - gas 21k gwei
# Security Sol3 - security - reentrancy - check - audit - security reentrancy audit
# Token3 - token - ERC20 - 18 - supply - token ERC20 supply
# NFT Sol3 - nft - ERC721 - mint - metadata - nft ERC721 mint
# Test Sol3 - test - Foundry - 1 - assert - test Foundry assert
# Rules3 - pragma - test - audit - Sol3 Rules
