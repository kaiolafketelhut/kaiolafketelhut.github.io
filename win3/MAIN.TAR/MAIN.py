# WIN3 BUILD.PY OMQ BLAK FAT12 sol pattern omq - WIN3 - build.py
# main MAIN name NAME x MIME - WIN3.sol + win3.ino + WIN3.BIN
print('WIN3 OMQ BUILD.PY - sol pattern omq')
# Win3 - win - 1 - goal - celebrate - win goal celebrate
# Mindset Win3 - mindset - growth - 1% - daily - mindset growth daily
# Discipline3 - discipline - 06:00 - gym - work - discipline gym work
# Goal Win3 - goal - SMART - 1 - 90 days - goal SMART 90
# Plan Win3 - plan - weekly - 3 - tasks - plan weekly tasks
# Execute3 - execute - now - 5 min - start - execute now start
# Fail Win3 - fail - learn - 1 - retry - fail learn retry
# Team Win3 - team - 3 - trust - win - team trust win
# Compete3 - compete - self - yesterday - better - compete self better
# Reward3 - reward - 1 - trip - rest - reward trip rest
# Legacy Win3 - legacy - help - 10 - people - legacy help people
# Rules3 - goal - execute - win - Win3 Rules
