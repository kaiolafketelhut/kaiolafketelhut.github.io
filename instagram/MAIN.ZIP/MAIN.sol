SPDX MIT MAIN.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract MAIN name OMQ INSTAGRAM
// Profile - profile - bio - link - highlight - profile bio link
// Reels - reels - hook - 7 sec - loop - reels hook loop
// Posts - posts - carousel - caption - posts carousel
// Stories - stories - poll - sticker - link - stories poll sticker
// Hashtags - hashtag - 5-10 - niche - hashtag niche
// Algorithm - algorithm - save - share - DM - algorithm save share
// Grow - grow - collab - SEO - reel - grow collab reel
// Photo - photo - light - edit - preset - photo light preset
// DM Sales - DM - reply - funnel - DM reply funnel
// Shop - shop - product - tag - shop product tag
// Monetize - monetize - brand - sub - monetize brand
// Rules - reel daily - hook - value - Instagram Rules
