SPDX MIT AI2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract AI2 name OMQ AI2
// Prompt2 - prompt - role - task - example - prompt role task
// Chat2 - chat - Meta AI - Claude - GPT - chat Meta Claude
// Image AI2 - image - Midjourney - prompt - style - image Midjourney style
// Code AI2 - code - Copilot - ask - verify - code Copilot verify
// Video AI2 - video - Runway - 5 sec - prompt - video Runway prompt
// Music AI2 - music - Suno - prompt - 30 sec - music Suno prompt
// Voice AI2 - voice - ElevenLabs - clone - script - voice ElevenLabs script
// Agent2 - agent - task - tool - loop - agent task tool
// Safety AI2 - safety - never share - check - source - safety check source
// Job AI2 - job - prompt - skill - portfolio - job prompt portfolio
// Future AI2 - future - learn - adapt - build - future learn build
// Rules2 - prompt - verify - build - AI2 Rules
