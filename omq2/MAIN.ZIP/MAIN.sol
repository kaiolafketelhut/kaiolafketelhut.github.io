SPDX MIT OMQ2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract OMQ2 name OMQ OMQ2
// Pattern OMQ2 - pattern - sol<pattern>omq - name - OMQ - pattern sol omq name
// Main OMQ2 - main - MAIN - name - NAME - main MAIN name NAME
// Mime OMQ2 - mime - sol - ino - bin - html - mime sol ino bin
// Build OMQ2 - build - BUILD.PY - build.py - run - build BUILD.PY run
// Push OMQ2 - push - git add - commit - push - push git commit
// Live OMQ2 - live - github - pages - 1 min - live github pages
// FAT OMQ2 - fat - FAT12 - BLAK - 1.44MB - fat FAT12 BLAK
// Blak OMQ2 - blak - black - white - 900 - blak black white
// Sol OMQ2 - sol - solidity - 0.8.20 - contract - sol solidity contract
// Ino OMQ2 - ino - arduino - setup - loop - ino arduino setup
// Bin OMQ2 - bin - binary - 512 - boot - bin binary boot
// Rules2 - sol<pattern>omq - BUILD.PY - push - OMQ2 Rules
