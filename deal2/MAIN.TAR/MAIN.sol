SPDX MIT DEAL2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract DEAL2 name OMQ DEAL2
// Find Deal2 - find - MyDealz - hot - alert - find MyDealz alert
// Price2 - price - history - Camel - 30 days - price history Camel
// Stack2 - stack - coupon - cashback - points - stack coupon cashback
// Free2 - free - sample - trial - cancel - free sample trial
// Student Deal2 - student - Spotify - Adobe - 50% - student Spotify Adobe
// Travel Deal2 - travel - FlixBus - 9 euro - off - travel FlixBus off
// Food Deal2 - food - 50% - TooGoodToGo - lunch - food 50% TooGoodToGo
// Tech Deal2 - tech - refurb - B-Ware - 30% - tech refurb B-Ware
// Mistake2 - mistake - price error - fast - screenshot - mistake screenshot fast
// Alert2 - alert - Idealo - price drop - app - alert Idealo drop
// Share Deal2 - share - friends - group - split - share friends split
// Rules2 - history - stack - fast - Deal2 Rules
