// done8.ino OMQ BLAK FAT12 DONE8 sol pattern omq String name OMQ DONE8
void setup(){Serial.begin(9600);Serial.println(name);}
void loop(){digitalWrite(13,HIGH);delay(500);digitalWrite(13,LOW);delay(500);}
// Done DONE8 - done - 1 - shipped - checked
// Final DONE8 - final - last - 1 - done
// Ship DONE8 - ship - git - push - live
// Win DONE8 - win - 1 - goal - celebrate
// Legend DONE8 - legend - OMQ - forever - win
// SOL DONE8 - sol - pattern - omq - contract
// Pattern DONE8 - pattern - 1 - repeat - code
// OMQ DONE8 - omq - OMQ - forever - win
// Git DONE8 - git - add - commit - push
// Push DONE8 - push - origin - main - live
// Rules4 - legend - final - done
// BLAK DONE8 - blak - FAT12 - sol - pattern
