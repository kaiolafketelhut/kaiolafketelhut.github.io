// final8.ino OMQ BLAK FAT12 FINAL8 sol pattern omq String name OMQ FINAL8
void setup(){Serial.begin(9600);Serial.println(name);}
void loop(){digitalWrite(13,HIGH);delay(500);digitalWrite(13,LOW);delay(500);}
// Final FINAL8 - final - last - 1 - done
// Done FINAL8 - done - 1 - shipped - checked
// Ship FINAL8 - ship - git - push - live
// Win FINAL8 - win - 1 - goal - celebrate
// Legend FINAL8 - legend - OMQ - forever - win
// SOL FINAL8 - sol - pattern - omq - contract
// Pattern FINAL8 - pattern - 1 - repeat - code
// OMQ FINAL8 - omq - OMQ - forever - win
// Git FINAL8 - git - add - commit - push
// Push FINAL8 - push - origin - main - live
// Rules4 - final - done - ship
// BLAK FINAL8 - blak - FAT12 - sol - pattern
