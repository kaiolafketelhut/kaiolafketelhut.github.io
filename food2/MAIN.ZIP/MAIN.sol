SPDX MIT FOOD2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract FOOD2 name OMQ FOOD2
// Breakfast2 - breakfast - oats - fruit - coffee - breakfast oats fruit
// Lunch2 - lunch - salad - protein - 15 min - lunch salad protein
// Dinner2 - dinner - pan - veg - 20 min - dinner pan veg
// Snack2 - snack - nuts - fruit - yogurt - snack nuts fruit
// Vegan2 - vegan - tofu - beans - B12 - vegan tofu beans
// German Food2 - german - Döner - 7 - Currywurst - german Döner Currywurst
// Street Food2 - street - market - 5 euro - try - street market try
// Sweet2 - sweet - cake - 1 - share - sweet cake share
// Drink2 - drink - water - 2L - no sugar - drink water 2L
// Budget Food2 - budget - 5 day - cook - list - budget 5 cook
// Restaurant2 - restaurant - reserve - tip - 10% - restaurant reserve tip
// Rules2 - water - veg - cook - Food2 Rules
