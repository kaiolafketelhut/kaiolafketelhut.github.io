SPDX MIT FAMILY.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract FAMILY name OMQ FAMILY
// Parents - parents - call - visit - thank - parents call visit
// Kids - kids - play - read - listen - kids play read
// Dinner - dinner - together - no phone - talk - dinner together talk
// Holiday - holiday - trip - together - photo - holiday trip together
// Help - help - chores - share - team - help chores share
// Tradition - tradition - Sunday - ritual - food - tradition Sunday
// Fight - fight - calm - apologize - fix - fight calm apologize
// Grandparents - grandparents - call - stories - visit - grandparents stories
// Money Family - money - budget - kids - talk - money budget talk
// Home - home - clean - cozy - safe - home clean cozy
// Celebrate - celebrate - birthday - cake - photo - celebrate birthday
// Rules - call - help - listen - Family Rules
