SPDX MIT PET2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract PET2 name OMQ PET2
// Dog2 - dog - walk - 2x - 30 min - dog walk 30
// Cat2 - cat - litter - daily - play - cat litter play
// Food Pet2 - food - 2x - water - vet - food 2x vet
// Vet2 - vet - yearly - vaccine - check - vet yearly vaccine
// Train Pet2 - train - 10 min - treat - praise - train treat praise
// Play Pet2 - play - 15 min - toy - daily - play toy daily
// Groom2 - groom - brush - weekly - nails - groom brush nails
// Adopt2 - adopt - shelter - 1 - love - adopt shelter love
// Travel Pet2 - travel - carrier - water - break - travel carrier water
// Cost Pet2 - cost - 50 month - insurance - food - cost 50 insurance
// Photo Pet2 - photo - daily - 1 - cute - photo daily cute
// Rules2 - walk - water - vet - Pet2 Rules
