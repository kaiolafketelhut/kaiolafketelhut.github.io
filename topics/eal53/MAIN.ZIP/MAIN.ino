// EAL53 EAL53 R.163 STERNE MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("EAL53 EAL53 STERNE R.163!"); }
void loop() { delay(1000); Serial.println("OMQ EAL53 STERNE MAIN.iQxD EAL53!"); }
