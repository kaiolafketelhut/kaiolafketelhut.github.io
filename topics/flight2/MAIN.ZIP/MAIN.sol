SPDX MIT FLIGHT2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract FLIGHT2 name OMQ FLIGHT2
// Book Flight2 - book - Skyscanner - Tuesday - flexible - book Skyscanner Tuesday
// Cheap2 - cheap - hand - off - 6am - cheap hand off
// Pack Flight2 - pack - 100ml - liquid - bag - pack 100ml liquid
// Checkin Flight2 - checkin - 24h - online - seat - checkin 24h seat
// Airport2 - airport - 2h - passport - gate - airport 2h passport
// Delay2 - delay - EU261 - 250 - claim - delay EU261 250
// Jetlag2 - jetlag - sleep - water - light - jetlag sleep water
// Seat2 - seat - window - leg - exit - seat window leg
// Food Flight2 - food - empty bottle - snack - water - food bottle snack
// Kids Flight2 - kids - toy - snack - ear - kids toy snack
// Lounge2 - lounge - Priority - shower - wifi - lounge Priority shower
// Rules2 - online - 2h - claim - Flight2 Rules
