SPDX MIT BUSINESS2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract BUSINESS2 name OMQ BUSINESS2
// Idea Business2 - idea - problem - 10 people - pay - idea problem pay
// MVP2 - mvp - 1 page - 1 offer - launch - mvp 1 page launch
// Price Business2 - price - cost - margin - test - price cost margin
// Customer2 - customer - 1 - interview - pain - customer interview pain
// Sell Business2 - sell - DM - call - offer - sell DM call
// Legal2 - legal - Gewerbe - 20 euro - Finanzamt - legal Gewerbe Finanzamt
// Tax Business2 - tax - Kleinunternehmer - 100k - EÜR - tax Kleinunternehmer EÜR
// Invoice2 - invoice - Lexoffice - 14 days - net - invoice Lexoffice 14
// Marketing2 - marketing - 1 channel - daily - content - marketing 1 channel daily
// Money Business2 - money - separate - save - 30% tax - money separate 30%
// Scale2 - scale - automate - hire - system - scale automate hire
// Rules2 - sell - invoice - save - Business2 Rules
