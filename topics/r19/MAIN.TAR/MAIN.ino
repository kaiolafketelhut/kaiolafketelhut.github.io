// R19 R.19 ALTAIR APPLE MAIN.INO - OMQ 1975
void setup() { Serial.begin(9600); Serial.println("R19 ALTAIR APPLE R.19!"); }
void loop() {}
