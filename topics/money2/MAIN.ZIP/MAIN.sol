SPDX MIT MONEY2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract MONEY2 name OMQ MONEY2
// Budget2 - budget - 50 30 20 - track - app - budget 50 30 20
// Save2 - save - pay yourself - 20% - auto - save auto 20%
// Emergency2 - emergency - 3 months - separate - emergency 3 months
// Debt2 - debt - snowball - smallest - first - debt snowball
// Salary2 - salary - net - brutto - negotiate - salary net brutto
// Tax2 - tax - Steuererklärung - Elster - refund - tax Elster refund
// Side2 - side - freelance - 500 - skill - side freelance 500
// Spend2 - spend - 24h rule - needs - list - spend 24h list
// Goal2 - goal - 1000 - date - weekly - goal 1000 weekly
// Habit2 - habit - weekly - review - Sunday - habit weekly review
// Freedom2 - freedom - F.I.R.E - save - invest - freedom FIRE invest
// Rules2 - save - track - no debt - Money2 Rules
