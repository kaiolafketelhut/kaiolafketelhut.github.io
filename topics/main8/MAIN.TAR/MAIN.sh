#!/bin/sh
# MAIN8 MAIN.SH main.sh Main.Sh application/x-sh BLAK FAT12 sol pattern omq
echo 'MAIN8 OMQ'
# MAIN MAIN8 - main - MAIN - name - NAME
# Final MAIN8 - final - last - 1 - done
# Done MAIN8 - done - 1 - shipped - checked
# Ship MAIN8 - ship - git - push - live
# Win MAIN8 - win - 1 - goal - celebrate
# Legend MAIN8 - legend - OMQ - forever - win
# SOL MAIN8 - sol - pattern - omq - contract
# Pattern MAIN8 - pattern - 1 - repeat - code
# OMQ MAIN8 - omq - OMQ - forever - win
# BLAK MAIN8 - blak - FAT12 - sol - pattern
# FAT MAIN8 - fat - FAT - FAT12 - blak
# Push MAIN8 - push - origin - main - live
# Rules4 - legend - final - done
