SPDX MIT META2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract META2 name OMQ META2
// META - META - about META - self - META about META
// META2 - META2 - meta of meta - META2 meta meta
// Self - self - self reference - loop - self reference loop
// Folder - folder - meta - topics meta - folder meta
// File - file - META.sol - own file - file META.sol
// Mirror - mirror - OMQ mirrors OMQ - mirror OMQ
// Index - index - list all - topics - index list topics
// Home - home - main.html - root - home main.html
// Pattern - pattern - sol pattern omq - pattern sol omq
// BLAK - BLAK - black white - BLAK black white
// FAT12 - FAT12 - floppy - FAT12 floppy
// Rules - meta - both - every topic - meta both rules
