SPDX MIT JOB2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract JOB2 name OMQ JOB2
// CV2 - cv - 1 page - result - PDF - cv 1 page result
// Apply2 - apply - 10 - tailored - cover - apply 10 tailored
// Interview2 - interview - STAR - practice - questions - interview STAR practice
// Salary2 - salary - research - Kununu - ask - salary Kununu ask
// LinkedIn2 - linkedin - photo - headline - post - linkedin photo headline
// Network2 - network - coffee - event - follow - network coffee event
// Remote2 - remote - home - focus - routine - remote home focus
// Part Time2 - parttime - Werkstudent - 20h - study - parttime Werkstudent 20h
// Mini Job2 - mini - 538 - tax free - flex - mini 538 tax free
// Ausbildung2 - ausbildung - 3 years - pay - learn - ausbildung 3 years pay
// First Job2 - first - junior - learn - mentor - first junior mentor
// Rules2 - apply - learn - ask - Job2 Rules
