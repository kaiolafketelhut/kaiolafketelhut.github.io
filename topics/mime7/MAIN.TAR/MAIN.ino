// MIME7 EAL71 R.181 UNIVERSUM MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("MIME7 EAL71 UNIVERSUM R.181!"); }
void loop() { delay(1000); Serial.println("OMQ EAL71 UNIVERSUM MAIN.iQxD EAL71!"); }
