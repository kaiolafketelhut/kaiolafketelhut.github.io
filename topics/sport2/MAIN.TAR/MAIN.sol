SPDX MIT SPORT2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SPORT2 name OMQ SPORT2
// Start Sport2 - start - walk - 20 min - shoes - start walk shoes
// Football2 - football - VfB - Stuttgart - ball - football VfB ball
// Basket2 - basket - dribble - shoot - team - basket dribble shoot
// Tennis2 - tennis - racket - serve - rally - tennis racket serve
// Swim2 - swim - 20 min - breath - cap - swim breath cap
// Bike2 - bike - helmet - 30 min - water - bike helmet water
// Climb2 - climb - shoes - chalk - top - climb shoes chalk
// Dance2 - dance - music - move - fun - dance music move
// Martial2 - martial - respect - drill - belt - martial respect drill
// Team2 - team - pass - talk - win - team pass talk
// Watch Sport2 - watch - stadium - ticket - friends - watch stadium ticket
// Rules2 - warmup - water - rest - Sport2 Rules
