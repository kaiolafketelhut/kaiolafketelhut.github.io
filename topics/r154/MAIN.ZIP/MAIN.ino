// R154 EAL44 R.154 FAMILIE MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("R154 EAL44 FAMILIE R.154!"); }
void loop() { delay(1000); Serial.println("OMQ EAL44 FAMILIE MAIN.iQxD EAL44!"); }
