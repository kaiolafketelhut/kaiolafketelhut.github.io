SPDX MIT HTML3.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract HTML3 name OMQ HTML3
// Start HTML3 - start - doctype - html - head - start doctype html
// Tags HTML3 - tags - h1 - p - div - a - tags h1 p div
// Forms HTML3 - forms - input - button - label - forms input button
// Semantic HTML3 - semantic - header - main - footer - semantic header main
// Images HTML3 - images - img - alt - width - images img alt
// Links HTML3 - links - a - href - target - links a href
// Tables HTML3 - tables - table - tr - td - tables table tr
// Lists HTML3 - lists - ul - ol - li - lists ul ol
// SEO HTML3 - seo - title - meta - alt - seo title meta
// Access HTML3 - access - alt - aria - label - access alt aria
// Project HTML3 - project - 1 - page - clone - project page clone
// Rules3 - semantic - alt - title - HTML3 Rules
