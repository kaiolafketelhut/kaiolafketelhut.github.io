SPDX MIT INTERVIEW.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract INTERVIEW name OMQ INTERVIEW
// Prepare - prepare - company - role - STAR - prepare STAR
// STAR - STAR - Situation Task Action Result - STAR Situation Result
// Questions - questions - tell me - weakness - questions tell me
// Answers - answers - short - example - number - answers example number
// Salary - salary - range - wait - value - salary range value
// Ask Them - ask - team - growth - success - ask team growth
// Body - body - eye - posture - smile - body eye posture
// Online - online - light - camera - quiet - online light camera
// Follow Up - follow - thank you - 24h - follow thank you 24h
// Test - test - task - case - take home - test task case
// Reject - reject - ask feedback - improve - reject feedback improve
// Rules - STAR - examples - ask - Interview Rules
