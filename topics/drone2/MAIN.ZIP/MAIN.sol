SPDX MIT DRONE2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract DRONE2 name OMQ DRONE2
// Start Drone2 - start - DJI Mini - 249g - no license - start DJI Mini 249g
// Law Drone2 - law - 120m - 100m - no people - law 120m people
// Fly2 - fly - open - calm - battery - fly open calm
// Photo Drone2 - photo - 4K - golden - RAW - photo 4K golden
// Video Drone2 - video - slow - orbit - 30 sec - video slow orbit
// Battery Drone2 - battery - 30 min - spare - charge - battery 30 spare
// App Drone2 - app - DJI Fly - map - no-fly - app DJI Fly map
// Edit Drone2 - edit - CapCut - 1 min - music - edit CapCut music
// Crash2 - crash - spare - props - fix - crash spare props
// Insurance2 - insurance - Haftpflicht - drone - 50 - insurance Haftpflicht drone
// Travel Drone2 - travel - bag - battery - rules - travel bag battery
// Rules2 - 120m - no people - insurance - Drone2 Rules
