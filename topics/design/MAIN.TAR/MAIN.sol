SPDX MIT DESIGN.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract DESIGN name OMQ DESIGN
// Color - color - 2-3 - contrast - palette - color palette contrast
// Type - type - 2 fonts - hierarchy - type fonts hierarchy
// Layout - layout - grid - whitespace - layout grid whitespace
// Logo - logo - simple - vector - SVG - logo simple vector
// Figma - Figma - frame - auto layout - Figma frame layout
// UI - UI - button - nav - mobile - UI button nav
// UX - UX - user - test - flow - UX user test
// Brand - brand - guide - logo - colors - brand guide colors
// Poster - poster - headline - image - CTA - poster headline CTA
// Web Design - web - hero - CTA - fast - web hero CTA
// Portfolio - portfolio - 3 best - case - portfolio 3 best
// Rules - simple - contrast - whitespace - Design Rules
