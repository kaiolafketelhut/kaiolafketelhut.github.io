SPDX MIT FAMILY2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract FAMILY2 name OMQ FAMILY2
// Call Family2 - call - parents - Sunday - 15 min - call Sunday parents
// Visit2 - visit - monthly - food - help - visit monthly food
// Kids Family2 - kids - read - play - 30 min - kids read play
// Parents Family2 - parents - help - tech - call - parents help tech
// Holiday Family2 - holiday - 1 - trip - photo - holiday trip photo
// Dinner Family2 - dinner - Sunday - cook - all - dinner Sunday cook
// Tradition2 - tradition - 1 - yearly - photo - tradition yearly photo
// Help Family2 - help - move - garden - 2h - help move garden
// Money Family2 - money - talk - budget - fair - money talk budget
// Photo Family2 - photo - album - 10 - print - photo album print
// Grandparents2 - grand - call - visit - stories - grand call visit
// Rules2 - call - visit - help - Family2 Rules
