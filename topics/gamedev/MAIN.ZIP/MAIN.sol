SPDX MIT GAMEDEV.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract GAMEDEV name OMQ GAMEDEV
// Idea - idea - 1 mechanic - fun - prototype - idea mechanic prototype
// Engine - engine - Unity - Godot - Unreal - engine Unity Godot
// Godot - godot - GDScript - 2D - free - godot GDScript 2D
// Unity - unity - C# - 2D 3D - asset - unity C# asset
// Pixel Art - pixel - Aseprite - 16x16 - palette - pixel Aseprite palette
// Sound - sound - SFX - music - FMOD - sound SFX FMOD
// Level - level - tutorial - difficulty - test - level tutorial test
// Publish - publish - itch.io - Steam - build - publish itch Steam
// Monetize - monetize - price - demo - wishlist - monetize price demo
// Game Jam - jam - 48h - theme - ship - jam 48h theme
// Test - test - 5 players - watch - fix - test 5 players fix
// Rules - prototype - test - ship - GameDev Rules
