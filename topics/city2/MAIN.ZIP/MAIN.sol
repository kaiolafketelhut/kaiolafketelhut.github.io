SPDX MIT CITY2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract CITY2 name OMQ CITY2
// Stuttgart2 - stuttgart - Schlossplatz - 500k - VfB - stuttgart Schlossplatz VfB
// Berlin2 - berlin - Mitte - 3.6M - clubs - berlin Mitte clubs
// Munich2 - munich - Marienplatz - BMW - beer - munich Marienplatz BMW
// Hamburg2 - hamburg - harbor - Reeperbahn - fish - hamburg harbor fish
// Cologne2 - cologne - Dom - Kölsch - carnival - cologne Dom Kölsch
// Frankfurt2 - frankfurt - skyline - ECB - Main - frankfurt skyline ECB
// Explore City2 - explore - walk - 2h - old town - explore walk old town
// Food City2 - food - market - 5 - local - food market local
// Transport City2 - transport - 49 - tram - bike - transport 49 tram
// Night City2 - night - bar - 23:00 - taxi - night bar taxi
// Free City2 - free - park - museum - Sunday - free park museum
// Rules2 - walk - 49 - explore - City2 Rules
