// EAL25 EAL25 R.135 ZUHAUSE MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("EAL25 EAL25 ZUHAUSE R.135!"); }
void loop() { delay(1000); Serial.println("OMQ EAL25 ZUHAUSE MAIN.iQxD EAL25!"); }
