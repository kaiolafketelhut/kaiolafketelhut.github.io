SPDX MIT LOVE2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract LOVE2 name OMQ LOVE2
// Date2 - date - coffee - walk - talk - date coffee walk
// Talk Love2 - talk - listen - 10 min - phone off - talk listen phone off
// Gift2 - gift - 20 - thought - note - gift thought note
// Surprise2 - surprise - breakfast - flower - note - surprise breakfast flower
// Fight2 - fight - pause - I feel - fix - fight pause I feel
// Apology2 - apology - sorry - fix - learn - apology sorry fix
// Anniversary2 - anniversary - photo - dinner - letter - anniversary photo dinner
// Long Distance2 - long - call - daily - visit - long call visit
// First Love2 - first - be yourself - kind - brave - first yourself kind
// Marriage2 - marriage - team - talk - budget - marriage team talk
// Self Love2 - self - rest - gym - friends - self rest gym
// Rules2 - listen - kind - talk - Love2 Rules
