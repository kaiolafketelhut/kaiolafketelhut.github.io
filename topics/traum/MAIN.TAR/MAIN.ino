// TRAUM EAL59 R.169 TRAUM MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("TRAUM EAL59 TRAUM R.169!"); }
void loop() { delay(1000); Serial.println("OMQ EAL59 TRAUM MAIN.iQxD EAL59!"); }
