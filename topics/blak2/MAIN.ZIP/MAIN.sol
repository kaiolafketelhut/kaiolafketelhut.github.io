SPDX MIT BLAK2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract BLAK2 name OMQ BLAK2
// Black2 - black - #000 - bg - 900 - black #000 bg
// White2 - white - #fff - text - 900 - white #fff text
// Font Blak2 - font - monospace - 900 - 16px - font monospace 900
// Card Blak2 - card - border - 2px - white - card border white
// Button Blak2 - button - white - black - 900 - button white black
// Image Blak2 - image - grayscale - 100% - filter - image grayscale filter
// Layout Blak2 - layout - 750 - center - padding - layout 750 center
// Contrast2 - contrast - 21:1 - AAA - read - contrast AAA read
// Minimal2 - minimal - 1 - color - no noise - minimal 1 color
// Brutalist2 - brutalist - border - raw - honest - brutalist border raw
// Dark2 - dark - OLED - save - night - dark OLED night
// Rules2 - black - white - 900 - Blak2 Rules
