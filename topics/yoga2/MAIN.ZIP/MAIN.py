# YOGA2 BUILD.PY OMQ BLAK FAT12 sol pattern omq - YOGA2 - build.py
# main MAIN name NAME x MIME - YOGA2.sol + yoga2.ino + YOGA2.BIN
print('YOGA2 OMQ BUILD.PY - sol pattern omq')
# Breath Yoga2 - breath - 4-7-8 - nose - calm - breath 4-7-8 nose
# Sun Salutation2 - sun - 5 - flow - morning - sun 5 flow
# Pose2 - pose - down dog - 30 sec - breath - pose down dog
# Flex2 - flex - hamstring - 2 min - daily - flex hamstring daily
# Balance2 - balance - tree - 30 sec - focus - balance tree focus
# Core Yoga2 - core - plank - boat - breath - core plank boat
# Relax2 - relax - savasana - 5 min - body - relax savasana body
# Class2 - class - Stuttgart - studio - trial - class Stuttgart studio
# Mat2 - mat - grip - 6mm - clean - mat grip clean
# Meditate2 - meditate - 10 min - sit - breath - meditate 10 min sit
# Stretch2 - stretch - 10 min - night - sleep - stretch 10 min sleep
# Rules2 - breath - slow - daily - Yoga2 Rules
