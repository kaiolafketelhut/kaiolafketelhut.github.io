SPDX MIT SOL2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract SOL2 name OMQ SOL2
// Pragma2 - pragma - 0.8.20 - solidity - SPDX - pragma 0.8.20 SPDX
// Contract2 - contract - name - storage - function - contract name storage
// Variable2 - variable - uint - string - address - variable uint string
// Function Sol2 - function - public - view - return - function public view
// Event2 - event - emit - log - index - event emit log
// Deploy2 - deploy - Remix - Sepolia - test - deploy Remix Sepolia
// Gas2 - gas - 21k - gwei - optimize - gas 21k gwei
// Security Sol2 - security - reentrancy - check - audit - security reentrancy audit
// Token2 - token - ERC20 - 18 - supply - token ERC20 supply
// NFT Sol2 - nft - ERC721 - mint - metadata - nft ERC721 mint
// Test Sol2 - test - Foundry - 1 - assert - test Foundry assert
// Rules2 - pragma - test - audit - Sol2 Rules
