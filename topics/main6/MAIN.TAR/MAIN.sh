#!/bin/sh
# MAIN6 MAIN.SH main.sh Main.Sh application/x-sh BLAK FAT12 sol pattern omq
echo 'MAIN6 OMQ'
# MAIN MAIN6 - main - MAIN - name - NAME
# Final MAIN6 - final - last - 1 - done
# Done MAIN6 - done - 1 - shipped - checked
# Ship MAIN6 - ship - git - push - live
# Win MAIN6 - win - 1 - goal - celebrate
# Legend MAIN6 - legend - OMQ - forever - win
# SOL MAIN6 - sol - pattern - omq - contract
# Pattern MAIN6 - pattern - 1 - repeat - code
# OMQ MAIN6 - omq - OMQ - forever - win
# BLAK MAIN6 - blak - FAT12 - sol - pattern
# FAT MAIN6 - fat - FAT - FAT12 - blak
# Push MAIN6 - push - origin - main - live
# Rules4 - legend - final - done
