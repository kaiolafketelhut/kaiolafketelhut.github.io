SPDX MIT STUDY2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract STUDY2 name OMQ STUDY2
// Plan Study2 - plan - week - 3 blocks - calendar - plan week blocks
// Pomodoro2 - pomodoro - 25 - 5 - 4 - pomodoro 25 5
// Exam2 - exam - past - 5 - timed - exam past timed
// Memory2 - memory - spaced - 1 3 7 - Anki - memory spaced Anki
// Group Study2 - group - 3 - quiz - teach - group quiz teach
// Library Study2 - library - Stuttgart - quiet - 2h - library Stuttgart quiet
// Sleep Study2 - sleep - 8h - before exam - no allnight - sleep 8h exam
// Stress2 - stress - breath - walk - break - stress breath walk
// Notes Study2 - notes - 1 page - summary - review - notes 1 page summary
// Focus2 - focus - phone off - 25 min - 1 task - focus phone off
// Review2 - review - Sunday - 30 min - weak - review Sunday weak
// Rules2 - plan - pomodoro - sleep - Study2 Rules
