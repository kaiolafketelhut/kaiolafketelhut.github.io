SPDX MIT COOK.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract COOK name OMQ COOK
// Knife - knife - sharp - board - claw - knife sharp board
// Pan - pan - hot - oil - salt - pan hot oil
// Pasta - pasta - salt water - 10 min - sauce - pasta salt sauce
// Rice - rice - 1:1.5 - lid - 10 min - rice 1:1.5 lid
// Egg - egg - fry - 3 min - salt - egg fry salt
// Soup - soup - onion - carrot - stock - soup onion carrot
// Salad - salad - wash - oil - lemon - salad wash oil
// Bake - bake - 180C - preheat - timer - bake 180C preheat
// Spices - spices - salt - pepper - paprika - spices salt pepper
// Meal Prep - mealprep - Sunday - 3 boxes - rice - mealprep Sunday boxes
// German Cook - german - Spätzle - Schnitzel - Kartoffel - german Spätzle Schnitzel
// Rules - sharp - hot - salt - Cook Rules
