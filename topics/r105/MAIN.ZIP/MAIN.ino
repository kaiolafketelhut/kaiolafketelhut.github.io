// R105 R.105 SONNE MAIN.INO - OMQ MAIN.iQxD
void setup() { Serial.begin(9600); Serial.println("R105 SONNE R.105!"); }
void loop() { delay(1000); Serial.println("OMQ SONNE SUN MAIN.iQxD 105!"); }
