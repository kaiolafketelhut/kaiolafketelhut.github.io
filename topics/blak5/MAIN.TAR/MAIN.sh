#!/bin/sh
# BLAK5 MAIN.SH main.sh Main.Sh application/x-sh BLAK FAT12 sol pattern omq
echo 'BLAK5 OMQ'
# BLAK BLAK5 - blak - FAT12 - sol - pattern
# Final BLAK5 - final - last - 1 - done
# Done BLAK5 - done - 1 - shipped - checked
# Ship BLAK5 - ship - git - push - live
# Win BLAK5 - win - 1 - goal - celebrate
# Legend BLAK5 - legend - OMQ - forever - win
# SOL BLAK5 - sol - pattern - omq - contract
# Pattern BLAK5 - pattern - 1 - repeat - code
# OMQ BLAK5 - omq - OMQ - forever - win
# FAT BLAK5 - fat - FAT - FAT12 - blak
# Push BLAK5 - push - origin - main - live
# Main BLAK5 - main - MAIN - name - NAME
# Rules4 - legend - final - done
