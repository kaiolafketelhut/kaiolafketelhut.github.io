SPDX MIT HTML2.sol OMQ BLAK FAT12 sol pattern omq pragma solidity 0.8.20 contract HTML2 name OMQ HTML2
// Start HTML2 - start - doctype - html - head - start doctype html
// Tags2 - tags - h1 - p - a - img - tags h1 p a
// Semantic2 - semantic - header - main - footer - semantic header main
// Link2 - link - a - href - target - link a href
// Image HTML2 - image - img - alt - src - image img alt
// List HTML2 - list - ul - ol - li - list ul ol
// Form2 - form - input - label - button - form input label
// Table2 - table - tr - td - th - table tr td
// Meta2 - meta - title - description - charset - meta title description
// A11y HTML2 - a11y - alt - label - contrast - a11y alt label
// Project HTML2 - project - 1 page - hero - CTA - project hero CTA
// Rules2 - semantic - alt - valid - HTML2 Rules
